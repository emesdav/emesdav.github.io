# SEPM-Estimation-App

## Installation

Python 3.10 required\
Install requirements from requirements.txt file\
main requirements: streamlit, pandas\
From parent directory run:\

```terminal
streamlit run Welcome.py
```
